
package main_src ;

public class WikitudeSDKConstants {

    /**
     * note that this key is only valid for this sample app, if you need one for your own application please visit www.wikitude.com (SDK Store)
     */
    public static final String WIKITUDE_SDK_KEY = "exybHjDDDtdFBST+3HaqIxldM3eU++acmRhNxuC+XqAFNSsPq1XZe23ibPRuPmSrEUQWUMO0smPhhSg0FY4mNnhEoh9RPDiQ0kLfMiGkQtMxKNtbRPpRO8VT9xCGBzWQtyJmcdaerqtz+fBdS8lq8wD+fzQS3Pb0jmb9Ljm1X25TYWx0ZWRfX2IIrsdex1PL4nePv6miW/uwq6jAg1QDIsMtOtwKpWTKRc7MqmNiCXW2yqnrNCBEhYPlT49gmJUGIeaBI9FaKOvt/p88vxD9RftsPHq1FoEKW6ik/Q18UbsTP9uSb1vxy2esJ3dBlPXuXLXPY494SFU0TBNbWjXRrTiyoewGjEEceOjnwatmWmaboncEFppwK0knzwBv7iwMSzYupxNVdFv0GAN8hWP65jUAETv+tSPdFi+q23CDSnMepYZmMp8JhA/dOyRSpv232hDx5M7hHcURSfP2yMH/jsnUtt6hccmV8nx3ag/JWEyskpHC4VwQHc45LNcYvvDqTdCP2eaXNEA/q1+pH7TjBWUeGdTqhAqAjy8rSdo0gMh7IM0giMFtzvqbLtb6HKLJ//cAIaVBgHtUfcApUGQ+IXKfBEaZpaBMyUviC8fO9pbfw9W0Vz6uz5LWfRcV55TMp3OFucN/oZ85plnvC/aF4tp/ekLyPlrsY9/z7UIFzTVPf4mfllY1sSNzOeWKkovkUdIn++f3mjfLgrSrFddNne2/a99LeecHq28y532OJAx6pd/SFIyIei9yBZ+fcpO/EDGkI/+0SHwVsdI8742KSEzCJh9n8K6jdGg06/O/Cb9TcT5CfPMM3mKLGz1aCCgG+psgnlNP4dTDQwbHxnTJ2C4575O9z5dpLTFHF3SxOvc=";


}
